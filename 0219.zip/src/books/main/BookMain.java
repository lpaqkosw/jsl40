package books.main;

import books.view.BookView;

public class BookMain {

	public static void main(String[] args) throws Exception {
		BookView v = new BookView();
		v.run();

	}

}
