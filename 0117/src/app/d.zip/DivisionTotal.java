package app.d;

public class DivisionTotal{
    Employee[] employees;
    int cnt;
    int totTmp;
    int total;

    public DivisionTotal(Employee[] employees, int cnt) {
        this.employees = employees;
        this.cnt = cnt;
    }
    
    public void printData(){
        String tmp = "";
        System.out.println("\n�μ�:\t\t���:\t�̸�:\t�޿�:");
        System.out.println("=================================================");
        for(int i =0;i<cnt;i++){
            if(i == 0){
                employees[i].printFirst();
                this.totTmp += employees[i].getPay();
                this.total += employees[i].getPay();
                tmp = employees[i].getDivision();
            }
            else{
                if(employees[i].getDivision().equals(tmp)){
                    employees[i].printData();
                    tmp = employees[i].getDivision();
                    this.totTmp += employees[i].getPay();
                    this.total += employees[i].getPay();
                    if(i==cnt-1){
                        System.out.println(tmp+" �հ�: \t\t\t"+String.format("%,d", this.totTmp));
                    }
                }
                else{
                    System.out.println(tmp+" �հ�: \t\t\t"+String.format("%,d", this.totTmp)+"\n");
                    tmp = employees[i].getDivision();
                    employees[i].printFirst();
                    this.total += employees[i].getPay();
                    this.totTmp = employees[i].getPay();
                    if(i==cnt-1){
                        System.out.println(tmp+" �հ�: \t\t\t"+String.format("%,d", this.totTmp));
                    }
                }
            }
        }
        System.out.println("\nTotal\t\t\t\t"+String.format("%,d", total));
    }
}