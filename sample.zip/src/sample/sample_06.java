package sample;

import java.util.Scanner;

public class sample_06 {
    public static void main(String[] args) throws Exception {
       
    }
}