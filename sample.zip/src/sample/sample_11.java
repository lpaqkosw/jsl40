package sample;

import java.util.Scanner;

public class sample_11 {
    public static void main(String[] args) throws Exception {
        
    }
}