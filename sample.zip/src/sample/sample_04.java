package sample;

import java.util.Scanner;

public class sample_04 {
    public static void main(String[] args) throws Exception {
        int sum =0;
        for(int i =0; i <=10; i++){
            sum += i;
        }
        System.out.println(sum);
    }
}