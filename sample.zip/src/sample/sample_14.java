package sample;

import java.util.Scanner;

public class sample_14 {
    public static void main(String[] args) throws Exception {
       
    }
}