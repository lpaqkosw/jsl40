package sample;

import java.util.Arrays;
import java.util.Scanner;

public class sample_25 {
    public static void main(String[] args) throws Exception {
      
    }
}



/*t c 1

45 23 86 41 2 27 66 30 81 15

*/