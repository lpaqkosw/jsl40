package app;

import app.j;

public class n {
    public static void main(String[] args) throws Exception {
        j.five();
    }
}