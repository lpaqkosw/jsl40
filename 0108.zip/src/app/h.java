package app;

import java.util.Arrays;

public class h {
    public static void main(String[] args) throws Exception {
        int[][] score = new int[5][6];
        for(int i = 0; i < score.length; i++){
            System.out.println(Arrays.toString(score[i]));

        }

    }
}