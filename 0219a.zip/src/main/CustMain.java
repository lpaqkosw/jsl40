package main;

import view.View;

public class CustMain {

	public static void main(String[] args) throws Exception{
		View view = new View();
		view.run();
		

	}

}
